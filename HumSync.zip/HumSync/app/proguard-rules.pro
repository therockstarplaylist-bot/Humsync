# No ProGuard rules needed — pure platform code
