package com.humsync.app;

import android.app.Activity;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

/**
 * HumSync — Pure Bio-Tone Generator
 * Generates a continuous 83.0 Hz sine wave using only the Android platform SDK.
 * No external libraries. No third-party audio engines.
 *
 * Breakthrough #5 executable: Bio-Tone / HumSync feedback loop.
 */
public class MainActivity extends Activity {

    private static final double FREQUENCY_HZ = 83.0;
    private static final int SAMPLE_RATE = 44100;
    private static final int BUFFER_SIZE_FACTOR = 2;

    private AudioTrack audioTrack;
    private boolean isPlaying = false;
    private Thread playbackThread;

    private Button btnPlay;
    private Button btnStop;
    private TextView statusText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnPlay = findViewById(R.id.btnPlay);
        btnStop = findViewById(R.id.btnStop);
        statusText = findViewById(R.id.status);

        btnPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startTone();
            }
        });

        btnStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopTone();
            }
        });
    }

    private void startTone() {
        if (isPlaying) return;

        int minBuffer = AudioTrack.getMinBufferSize(
                SAMPLE_RATE,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT);

        int bufferSize = minBuffer * BUFFER_SIZE_FACTOR;

        audioTrack = new AudioTrack(
                AudioManager.STREAM_MUSIC,
                SAMPLE_RATE,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                bufferSize,
                AudioTrack.MODE_STREAM);

        if (audioTrack.getState() != AudioTrack.STATE_INITIALIZED) {
            statusText.setText("ERROR: AudioTrack failed to initialize");
            return;
        }

        isPlaying = true;
        btnPlay.setEnabled(false);
        btnStop.setEnabled(true);
        statusText.setText(getString(R.string.status_playing));

        playbackThread = new Thread(new Runnable() {
            @Override
            public void run() {
                short[] buffer = new short[bufferSize / 2];
                double angle = 0.0;
                double angularFrequency = 2.0 * Math.PI * FREQUENCY_HZ / SAMPLE_RATE;

                audioTrack.play();

                while (isPlaying) {
                    for (int i = 0; i < buffer.length; i++) {
                        buffer[i] = (short) (Math.sin(angle) * Short.MAX_VALUE * 0.7); // 70% amplitude to avoid clipping
                        angle += angularFrequency;
                        if (angle > 2.0 * Math.PI) {
                            angle -= 2.0 * Math.PI;
                        }
                    }
                    audioTrack.write(buffer, 0, buffer.length);
                }

                audioTrack.stop();
                audioTrack.release();
                audioTrack = null;
            }
        });
        playbackThread.start();
    }

    private void stopTone() {
        if (!isPlaying) return;

        isPlaying = false;
        btnPlay.setEnabled(true);
        btnStop.setEnabled(false);
        statusText.setText(getString(R.string.status_idle));

        // Thread will exit cleanly and release AudioTrack
        try {
            if (playbackThread != null) {
                playbackThread.join(500);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        stopTone();
    }

    @Override
    protected void onDestroy() {
        stopTone();
        super.onDestroy();
    }
}
