# HumSync — Bio-Tone 83 Hz Generator

**Breakthrough #5 Executable**  
Pure Android platform SDK. Zero external libraries.

## Exact File Tree

```
HumSync/
├── settings.gradle
├── build.gradle
├── gradle.properties
├── README.md
└── app/
    ├── build.gradle
    ├── proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml
        ├── java/com/humsync/app/
        │   └── MainActivity.java
        └── res/
            ├── layout/
            │   └── activity_main.xml
            └── values/
                └── strings.xml
```

## Dependencies

**None.**  
Only the Android platform SDK (API 24+).  
No androidx, no Google libraries, no third-party audio engines.

## How to Build the APK (on your machine)

1. Install Android Studio (or command-line tools + SDK 34).
2. Open the `HumSync` folder as a project.
3. Let Gradle sync (it will download the Android Gradle Plugin once).
4. Build → Build Bundle(s) / APK(s) → Build APK(s)
5. Or from terminal inside the project root:

```bash
./gradlew assembleDebug
```

APK will appear at:  
`app/build/outputs/apk/debug/app-debug.apk`

## What the App Does

- Continuous pure sine wave at **exactly 83.0 Hz**
- Generated with `AudioTrack` + `Math.sin` (no samples, no files)
- Play / Stop controls
- Automatic stop on pause/destroy
- 70% amplitude to prevent clipping
- Sample rate 44100 Hz, 16-bit mono

## Tester Mode Instructions

1. Install the APK on a real device (or emulator with audio).
2. Open HumSync → tap **PLAY 83 Hz**.
3. Record the speaker output with a second device or spectrum analyzer app.
4. Confirm the fundamental peak sits at 83 Hz (±0.5 Hz tolerance due to device clock).

This is the shippable binary for Breakthrough #5.
